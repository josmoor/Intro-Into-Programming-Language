Python Sorting file:
- To run the script, use the command: python3 Sort.py
- The program will then ask for an input of 10 integers (can be less). If a non-numerical value is given, the loop is exited.
- After the program intakes the values, using a selection sort an array of values are then put into ascending order and displayed.

Perl Sorting File:
- To run the Perl Script, use the command: perl Sort.pl
- The program will ask the user to input 10 integers into an array. If you input a non-numerical value, then the program sorts and displays what's been given.
- After the values are inputted, the program then sorts the numerical values into ascending order and displays the results to the terminal.